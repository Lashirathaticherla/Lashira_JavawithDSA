package collections;
import java.util.ArrayList;
import java.util.Vector;
public class ArrayListModify {
public static void main(String[] args)
    {
  
        // create an empty array list with an initial capacity
  //   ArrayList<Integer> age = new ArrayList<Integer>();
     Vector age = new Vector();
        // use add() method to add elements in the list
   System.out.println(age.capacity());  
    System.out.println(age.size()); 
        age.add(10);
        age.add(3);
        age.add(10);
        age.add(19);
        age.add(12);
        age.add(9);
        System.out.println("Full Age List");
        System.out.println(age);
//       
    
        //use remove() method to remove 
        System.out.println("Before The Deletion of Age List");
        System.out.println(age);
        age.remove(1);
//        
        System.out.println("After The Age in the index 1 is Deleted i.e 3");
        System.out.println(age);
        
        //use add() method to do the update
        System.out.println("After Adding the Age (11) in the index 1 which is deleted");
        age.add(1, 11);
        System.out.println(age);
  }
}
//
//{ 
//    public static void main(String args[]) 
//    { 
//        int arr[][] = new int[3][]; 
//        arr[0] = new int[1]; 
//        arr[1] = new int[2]; 
//        arr[2] = new int[3];                
//int sum = 0; 
//for (int i = 0; i < 3; ++i)  
//    for (int j = 0; j < i + 1; ++j) 
//                arr[i][j] = j + 1; 
//for (int i = 0; i < 3; ++i)  
//    for (int j = 0; j < i + 1; ++j) 
//                sum + = arr[i][j]; 
//System.out.print(sum); 	 
//    }  
//} 



