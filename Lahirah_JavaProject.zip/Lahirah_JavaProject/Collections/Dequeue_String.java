package collections;

import java.util.Deque;
import java.util.LinkedList;


 public class Dequeue_String {

    public static void main(String[] args) {
        // Creating Deque using the LinkedList class
        Deque<String> name = new LinkedList<>();
		/*
		 * Deque<String> name2 = new LinkedList<>(); name2.add(null);
		 * System.out.println(name2.hashCode());
		 */        

        // add elements to the Deque
        name.add("Siva");
        name.add("");
        name.addLast("Shan");
        name.addFirst("Nan");
        name.addFirst("");
        System.out.println(name.hashCode());  
        System.out.println("Deque: " + name);

        
        for(String item:name) {
        	if(name.equals("")) {
        		System.out.println(item);
        	}
        }
       
        // Access elements of the Deque
        String firstElement = name.peekFirst();
        System.out.println("First Element: " + firstElement);

        String lastElement = name.peekLast();
        System.out.println("Last Element: " + lastElement);

        // Remove elements from the Deque
        String removedName1 = name.pollFirst();
        System.out.println("Removed First Element: " + removedName1);

        String removedName2 = name.pollLast();
        System.out.println("Removed Last Element: " + removedName2);

        System.out.println("Updated Deque: " + name);
        
        //Can't Insert or Remove In dequeue or Queue
    //    System.out.println(name.remove(1));
    }
}

