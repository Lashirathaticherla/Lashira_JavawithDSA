package collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.*;

public class Linked_Array_List {
	public static void main(String[] args) {
		LinkedList<String> familyRegister= new LinkedList<String>();
		
		familyRegister.add("Father");
		familyRegister.add("Mother");
		familyRegister.add("GrandMa");
		familyRegister.add("GrandPa");
		familyRegister.add("Sister 1");
		familyRegister.add("Sister 2");
		familyRegister.add("Tiger");
		
		ArrayList<String>familyRegisters = new ArrayList<String>(familyRegister);
		System.out.println(familyRegisters);
		
		HashSet<String> family = new HashSet<>(familyRegisters);
		System.out.println(family);
	}
	
}
