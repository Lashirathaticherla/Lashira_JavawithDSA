package collections;

import java.util.PriorityQueue;

class NaturalChoice
{
	public static void main(String args[]) {
		  PriorityQueue<String> testStrings=new PriorityQueue<String>();  
    
    testStrings.add("abcd");
    testStrings.add("1234");
    testStrings.add("23bc");
    testStrings.add("zzxx");
    testStrings.add("abxy");

    System.out.println("Strings Stored in Natural Ordering in a Priority Queue\n");
    while (!testStrings.isEmpty()) {
        System.out.println(testStrings.poll());
    }
}
}