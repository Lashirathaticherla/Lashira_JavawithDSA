package JavaExerciseProgarm;

import JavapracticeProgram.Arthematicoperation1;

public class Callingarthematic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arthematicoperation1 obj=new Arthematicoperation1();
		System.out.print(obj.sum(6, 6));

	}

}
