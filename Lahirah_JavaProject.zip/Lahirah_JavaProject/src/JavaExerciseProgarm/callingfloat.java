package JavaExerciseProgarm;

import JavapracticeProgram.float1;

public class callingfloat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float1 obj=new float1();
		System.out.print(obj.sum(10.8f, 23.2f));
		

	}

}
