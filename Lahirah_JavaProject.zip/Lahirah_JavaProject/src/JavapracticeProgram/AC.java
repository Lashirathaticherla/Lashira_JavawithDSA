package JavapracticeProgram;

class AC extends temp1 {

	void run()
	{
		System.out.println("running safely...");
	}
	public static void main(String[] args) {
		temp1 obj = new AC();
		obj.run();
	}
}


