package JavapracticeProgram;

public class ArrayWithDatatypesUL {
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			 float a[]= {1.1f,2.2f,3.3f};
			System.out.println(a[1]);
			
			// Double
			double b[]= {112.34,2234.23,323456.234};
			System.out.println(b[1]);
			
			// long
			long c[]= {112345678,1234567892,309876};
			System.out.println(c[1]);
			
			// String
			String d[]= {"HI","Hello","WElCOME"};
			System.out.println(d[1]);
		    
			// byte
			byte e[]= {1,2,3};
			System.out.println(e[1]);
		
		
		
		}

	}

