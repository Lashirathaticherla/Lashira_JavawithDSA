package JavapracticeProgram;



	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Scanner;
	public class ArraylistSorting {
		

	
	public static void main(String[] args) {
	// Creating A List Full of Diameter
	 ArrayList<Float> diameter = new ArrayList<Float>();
	 try (Scanner scan = new Scanner(System.in)) {
		float diameters =scan.nextFloat();
		 diameter.add(diameters);
	}
	 diameter.add(5.44f);
	 diameter.add(4.55f);
	 diameter.add(3.33f);
	 diameter.add(6.44f);
	 diameter.add(7.55f);
	 diameter.set(4,8.88f );
	 
	 // Creating A List full Of radius
	 ArrayList<Float> radius = new ArrayList<Float>();
	 radius.add(23.00f);
	 radius.add(22.00f);
	 radius.add(24.00f);
	 radius.add(23.00f);
	 radius.add(22.00f);
	 radius.add(24.00f);
	 
	 //Printing The List With Radius 
	 
	 System.out.println("radius Details");
	 System.out.println(radius);
	 
	 //Sorting The Diameter
	 System.out.println("Before Sorting The Diameter");
	 System.out.println(diameter);
	 System.out.println("After Sorting The Diameter");
	 Collections.sort(diameter);
	 System.out.println(diameter);
	 
	 //Shuffling The Diameter
	 System.out.println("After Shuffling The Diameter");
	 Collections.shuffle(diameter);
	 System.out.println(diameter);
	 
	 //Finding The Maximum Of Diameter in List
	 System.out.println("After Finding The Maximum Diameter");
	 System.out.println( Collections.max(diameter));
	 
	 //FInding The Minimum of Diameter in List
	 System.out.println("After Finding The Minimum Diameter");
	 System.out.println( Collections.min(diameter));
	 
	 //Reverse  Order of The Diameter
	 System.out.println("Before Reverse The Order");
	 System.out.println(diameter);
	 Collections.reverse(diameter);
	 System.out.println("After Reverse The Order");
	 System.out.println(diameter);

	 //Copying The Diameter To Radius 
	 Collections.copy(diameter, radius);
	 System.out.println("After Copying the Diameter Into The radius the radius Will Be");
	 System.out.println(diameter);
	 
	}}


