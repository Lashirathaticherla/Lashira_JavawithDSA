package JavapracticeProgram;

public class Arthematiccalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c,d,e,f;
		a=10;
		b=20;
		c=a+b;
		d=a-b;
		f=a*b;
		e=a/b;
		System.out.println("enter the value c is addition:"+c);
		System.out.println("enter the value d is substraction:"+d);
		System.out.println("enter the value f is multiplication:"+f);
		System.out.println("enter the value e is division:"+e);
		

	}

}
