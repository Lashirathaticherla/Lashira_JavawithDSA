package JavapracticeProgram;

public class Arthematicoperation1 {
	public int sum(int a, int b) 
		{
			int c = a + b;
			return c;
		}

	}

