package JavapracticeProgram;

public class Bankp {
	float getRateOfInterest()
	{
		return 0;
	}

}
