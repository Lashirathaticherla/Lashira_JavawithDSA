package JavapracticeProgram;

class Biriyani {
	
		void run() {
		System.out.println("Parent Method");
	}  
	}  						
	class KFC_Chicken extends Biriyani{
	   void run()  
	   {
		   System.out.println("Child Method");
	   }  
	  public static void main(String args[]){  
		  KFC_Chicken obj = new KFC_Chicken();	
		  obj.run();  
		  Biriyani obj1 = new Biriyani();
		  obj1.run();
	  }  
	} 


