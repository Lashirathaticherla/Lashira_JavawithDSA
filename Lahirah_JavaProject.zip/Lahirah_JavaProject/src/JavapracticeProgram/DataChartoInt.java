package JavapracticeProgram;

public class DataChartoInt {

	public static void main(String[] args) {
		char ch='A';
		int code=ch;
		System.out.println(code);
		// TODO Auto-generated method stub

	}

}
