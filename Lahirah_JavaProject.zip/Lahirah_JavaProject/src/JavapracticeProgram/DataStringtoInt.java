package JavapracticeProgram;

public class DataStringtoInt {

	public static void main(String[] args) {
		String s="30";
		int n=Integer.parseInt(s);
		System.out.println(n + 10);
		// TODO Auto-generated method stub

	}

}
