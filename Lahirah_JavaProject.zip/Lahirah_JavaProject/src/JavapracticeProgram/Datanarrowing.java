package JavapracticeProgram;

public class Datanarrowing {

	public static void main(String[] args) {
		double x=9.99;
		int y=(int)x;
		System.out.println(y);
		// TODO Auto-generated method stub

	}

}
