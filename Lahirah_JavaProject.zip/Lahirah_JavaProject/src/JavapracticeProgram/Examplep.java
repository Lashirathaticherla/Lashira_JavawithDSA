package JavapracticeProgram;

public class Examplep {

	public static void main(String[] args) {
		Bankp obj;
		obj=new SBI();
		System.out.println("SBI Rate of Interest:"+obj.getRateOfInterest());
		obj=new ICICI();
		System.out.println("ICICI Rate of interest:"+obj.getRateOfInterest());
		obj=new HDFC();
		System.out.println("HDFC Rate of Interest:"+obj.getRateOfInterest());// TODO Auto-generated method stub

	}

}
