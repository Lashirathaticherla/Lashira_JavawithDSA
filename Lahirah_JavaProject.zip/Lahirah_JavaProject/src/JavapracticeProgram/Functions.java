package JavapracticeProgram;

public class Functions {
	public static void add(int a,int b) {
		int c=a+b;
		System.out.println("the sum is:"+c);
	}

	public static void main(String[] args) {
		add(5,14);
		// TODO Auto-generated method stub

	}

}
