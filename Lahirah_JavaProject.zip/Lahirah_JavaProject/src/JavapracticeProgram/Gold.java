package JavapracticeProgram;

public class Gold {

		private String name;

		public String getName()

		{

			return name;

		}

		public void setName(String newName) {

			name=newName;

		}

	



}



