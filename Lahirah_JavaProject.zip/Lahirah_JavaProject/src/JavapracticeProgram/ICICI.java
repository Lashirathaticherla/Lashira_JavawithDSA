package JavapracticeProgram;

public class ICICI extends Bankp {
	float getRateOfInterest() {
		return 7.3f;
	}

}
