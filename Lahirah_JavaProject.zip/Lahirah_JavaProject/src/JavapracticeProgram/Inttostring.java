package JavapracticeProgram;

public class Inttostring {

	public static void main(String[] args) {
		int num=123;
		String str =String.valueOf(num);
		System.out.println(str+"abc");
		// TODO Auto-generated method stub

	}

}
