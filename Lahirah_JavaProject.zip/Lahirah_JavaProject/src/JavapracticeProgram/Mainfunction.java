package JavapracticeProgram;

public class Mainfunction {

	public static void main(String[] args) {
		Snacks obj=new Snacks();
		obj.print();
		obj.print1();
		// TODO Auto-generated method stub

	}

}
