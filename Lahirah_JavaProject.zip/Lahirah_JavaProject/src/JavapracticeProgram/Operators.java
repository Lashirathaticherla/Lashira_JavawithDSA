package JavapracticeProgram;

public class Operators {

	public static void main(String[] args) {
		int a=12,b=24;
		System.out.println("a+b+"+(a+b));
		System.out.println("a>b:"+(a>b));
		System.out.println("(a>0&&B>0):"+(a>0&&b>0));
		a+=b;
		System.out.println("a after+=b:"+a);
		System.out.println("++b="+(++b));
		String result=(a>b)?"a is greater":"b is greater";
		System.out.println(result);
		// TODO Auto-generated method stub

	}

}
