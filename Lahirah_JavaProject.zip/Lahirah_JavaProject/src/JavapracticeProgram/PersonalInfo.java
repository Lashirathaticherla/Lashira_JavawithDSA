package JavapracticeProgram;

public class PersonalInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name="Lashirah";
		int age=19;
		char gender='F';
		String phone="8889309301";
		String address="Anantapuram,India";
		System.out.println("----Personal information----");
		System.out.println("Name:" + name);
		System.out.println("Age:" +age);
		System.out.println("gender:" +gender);
		System.out.println("phone:" +phone);
		System.out.println("Address:" +address);
		
			
		
		

	}

}
