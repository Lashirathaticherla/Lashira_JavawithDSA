package JavapracticeProgram;

public class PrintStatement {

	public static void main(String[] args) {
		System.out.println("hi welcome hi ");// TODO Auto-generated method stub

	}

}
