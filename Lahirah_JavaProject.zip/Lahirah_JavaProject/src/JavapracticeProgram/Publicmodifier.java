package JavapracticeProgram;

public class Publicmodifier {

	 void main(String[] args) {
		 int a,b,c;
		 a=12;
		 b=23;
		 c=a+b;
		 System.out.println(c);
		
		// TODO Auto-generated method stub

	}

}
