package JavapracticeProgram;

public class SBI extends Bankp {
	float getRateOfInterest() {
		return 8.4f;
	}
}
