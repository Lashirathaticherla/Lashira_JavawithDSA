package JavapracticeProgram;

import java.util.Scanner;

public class Scannerinput {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.print("enter name:");
		String name=sc.next();
		System.out.print("Enter age:");
		int age=sc.nextInt();
		System.out.print("Hello!"+name+"and my age is"+age);
		// TODO Auto-generated method stub

	}

}
