package JavapracticeProgram;

public class Snacks implements Zomato,Swiggy {
	public void print() {
		System.out.println("Welcome.......");
	}
	public void print1() {
		System.out.println("To Javaa....");
		
	}

}
