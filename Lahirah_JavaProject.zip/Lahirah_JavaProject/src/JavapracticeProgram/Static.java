package JavapracticeProgram;

public class Static{
	static int number=45;
	static void display() {
		System.out.println("Number+"+number);
	}

	public static void main(String[] args) {
		display();
		// TODO Auto-generated method stub

	}

}
