package JavapracticeProgram;

public class Stringtartended {
		public static void main(String args[]){
			 
			   String s="Seetha";
			   System.out.println(s.startsWith("Se"));//true
			   System.out.println(s.endsWith("a"));//true
			 }
	}



