package JavapracticeProgram;

public interface Swiggy {
	void print1();
	

}
