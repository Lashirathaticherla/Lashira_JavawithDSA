package JavapracticeProgram;

public class Switchcase {

	public static void main(String[] args) {
		int day=3;
		switch(day) {
		case 1:
			System.out.println("Monday");
		break;
		case 2:
			System.out.println("tuesday");
		break;
		case 3:
			System.out.println("Wednesday");
			break;
		case 4:
			System.out.println("thursday");
			break;
			default:
				System.out.println("Invalid day number");
		}
		// TODO Auto-generated method stub

	}

}
