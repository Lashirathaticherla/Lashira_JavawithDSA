package JavapracticeProgram;

 abstract public class Temp {
	 abstract void run();

}
