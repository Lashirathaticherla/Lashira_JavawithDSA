package JavapracticeProgram;

public class VariableValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=14;
		System.out.println("the value of number is: "+number);
	}

}
