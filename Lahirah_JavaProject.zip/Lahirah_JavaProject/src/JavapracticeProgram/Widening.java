package JavapracticeProgram;

public class Widening {

	public static void main(String[] args) {
		int a= 10;
		double b=a;
		System.out.println(b);
		
		// TODO Auto-generated method stub

	}

}
