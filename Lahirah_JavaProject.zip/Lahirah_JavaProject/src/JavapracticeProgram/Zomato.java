package JavapracticeProgram;

public interface Zomato {
	void print();

}
