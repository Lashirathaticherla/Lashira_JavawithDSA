package JavapracticeProgram;

public class cash {
			public static void main(String[] args) {

				Gold obj = new Gold();

				obj.setName("Lashira h");

				System.out.println("Name : "+ obj.getName());

			}

		}


