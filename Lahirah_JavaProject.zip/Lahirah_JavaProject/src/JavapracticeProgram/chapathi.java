package JavapracticeProgram;

 class chapathi {
	 void run() {
		 System.out.println("Parent Method");
	}  
	}  						
 class curry extends chapathi{
	 void run()  
	 {
		 System.out.println("Child Method");

	   }  
	 public static void main(String args[]){  
		 curry obj = new curry();	
		 obj.run();  
		 chapathi  obj1 = new chapathi();
		 obj1.run();

	  }  

	}


