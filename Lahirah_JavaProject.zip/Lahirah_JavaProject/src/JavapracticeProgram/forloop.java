package JavapracticeProgram;

public class forloop {
	static int i;
	public static void main(String[] args) {
		for(i=1;i<=10;i++)
			System.out.println("number:"+i);
		// TODO Auto-generated method stub

	}

}
