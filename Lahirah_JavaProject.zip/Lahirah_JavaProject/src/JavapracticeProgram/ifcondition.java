package JavapracticeProgram;

public class ifcondition {

	public static void main(String[] args) {
		int a=10;
		int b=5;
		if(a>b) {
			System.out.println("a is greateer than b");
		}
		
		// TODO Auto-generated method stub

	}

}
