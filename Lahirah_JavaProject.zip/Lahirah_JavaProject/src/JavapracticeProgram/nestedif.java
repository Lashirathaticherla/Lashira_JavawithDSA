package JavapracticeProgram;

public class nestedif {

	public static void main(String[] args) {
		int age=18;
		boolean hasID= true;
		if(age>=16) {
			if(hasID) {
				System.out.println("you are allowed to enter");
			}
		}
		// TODO Auto-generated method stub

	}

}
