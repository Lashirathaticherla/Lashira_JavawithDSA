package JavapracticeProgram;

public class sam {

}
