package JavapracticeProgram;

public class string1 {

}
