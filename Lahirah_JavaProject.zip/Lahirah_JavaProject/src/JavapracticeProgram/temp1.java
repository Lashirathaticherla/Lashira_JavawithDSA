package JavapracticeProgram;

abstract class temp1 {
	abstract void run();
}

