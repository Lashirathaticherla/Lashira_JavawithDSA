package JavapracticeProgram;

public class whileloop {

	public static void main(String[] args) {
		int count=0;
		while(count<=5) {
			System.out.println(0);
			count++;
		}
		// TODO Auto-generated method stub

	}

}
