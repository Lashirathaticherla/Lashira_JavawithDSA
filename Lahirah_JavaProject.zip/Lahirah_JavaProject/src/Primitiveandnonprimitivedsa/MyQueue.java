package Primitiveandnonprimitivedsa;

public class MyQueue {

		private int[] queue;

		private int front, rear, size, capacity;



		public MyQueue(int capacity) {

			this.capacity = capacity;

			queue = new int[capacity];

			front = 0;

			rear = -1;

			size = 0;

		}



		public void enqueue(int value) {

			if (isFull()) {

				System.out.println("Queue is full");

				return;

			}

			rear = (rear + 1) % capacity;

			queue[rear] = value;

			size++;

			System.out.println("Enqueued: " + value);

		}



		public int dequeue() {

			if (isEmpty()) {

				System.out.println("Queue is empty!");

				return -1;

			}

			int removed = queue[front];

			front = (front + 1) % capacity;

			size--;

			return removed;

		}

		public int peek() {

			if (isEmpty()) {

				System.out.println("Queue is empty!");

				return -1;

			}

			return queue[front];

		}

		public boolean isEmpty() {

			return size == 0;

		}

		public boolean isFull() {

			return size == capacity;

		}

		public void display() {

			System.out.println("Queue: ");

			for (int i = 0; i < size;i++) {

				int index = (front + i)% capacity;

				System.out.println(queue[index] + " ");

			}

			System.out.println();

		}

		public static void main(String[] args) {

			MyQueue q = new MyQueue(5);

			

			q.enqueue(10);

			q.enqueue(20);

			q.enqueue(30);

			q.display();

			

			System.out.println("Dequeued: "+ q.dequeue());

			q.display();

			



			System.out.println("Front element: "+ q.peek());

		}

	}
	


