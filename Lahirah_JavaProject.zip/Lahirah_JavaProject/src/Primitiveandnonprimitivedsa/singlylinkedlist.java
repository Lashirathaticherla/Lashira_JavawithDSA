package Primitiveandnonprimitivedsa;

 class singlylinkedlist {
		 static class Node{
			 int data;
			 Node next;
			 Node(int data){
				 this.data=data;
				 this.next=null;
				 
			 }
		 }
		 Node head= null;
		 public void insert(int data) {
			 Node newNode=new Node(data);
			 if(head==null) {
				 head=newNode;
				 
			 }else {
				 Node temp=head;
				 while(temp.next!=null) {
					 temp=temp.next;
				 }
				 temp.next= newNode;
				 }
			 
				 
			 }
			 public void delete(int value) {
				 if(head==null) {
					 System.out.println("List is empty!");
					 return;
				 }
				 Node current =head;
				 Node previous =null;
				 while(current !=null &&current.data !=value) {
					 previous=current;
					 current=current.next;
				 }
				 if(current== null) {
					 System.out.println("value not found!");
					 return;
				 }
				 previous.next=current.next;
				 
			 }
			 public boolean search(int key) {
				 Node temp=head;
				 while (temp  !=null) {
					 if (temp.data ==key) {
						 return true;
						 
					 }
					 temp =temp.next;
				 }
				 return false;
			 }
			 public void display() {
				 if(head==null) {
					 System.out.println("List is empty.");
					 return;
				 }
				 Node temp=head;
				 System.out.println("Linked List:");
				 while (temp!=null) {
					 System.out.println(temp.data+"");
					 temp=temp.next;
					 
				 }
				 System.out.println("NULL");
	      }		 
				 public static void main(String[] args) {
					 singlylinkedlist list=new singlylinkedlist();
					 list.insert(10);
					 list.insert(20);
					 list.insert(30);
					 list.insert(40);
					 list.display();
					 
					 System.out.println("Searching 30:"+list.search(30));
					 list.delete(20);
					 list.display();
					 list.delete(10);
					 list.display();
				 }
			// TODO Auto-generated method stub

		}
 
	