package TreeandMap;

public class Hashmap5 {

}
