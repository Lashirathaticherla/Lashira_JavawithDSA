package TreeandMap;


	import java.util.HashMap;
	import java.util.LinkedHashMap;
	import java.util.TreeMap;
	public class Hashmapgetmethod {

	    public static void main(String[] args) 
	    {
	        //Creating HashMap with default initial capacity and load factor
	         
	        HashMap<String, Integer> map = new HashMap<String, Integer>();
	         
	        //Adding key-value pairs to HashMap
	         
//	        map.put("John", 32);
//	         
//	        map.put("Steve", 30);
//	         
//	        map.put("Angie", 33);
//	         
//	      //  map.put("FOUR", 4);
//	        for(String i:map.keySet()) {
//	        	System.out.println(i);
//	        	System.out.println("Name:"+i+"Age:"+map.get(i));
//	        }
//	         
//	        System.out.println(map);
	        //Retrieving a value associated with key 'TWO'
	         
			
			//  int value = map.get("TWO");
			 
			// System.out.println(value);
	        map.put("ONE", 1);
	        
	        map.put("TWO", 2);
	         
	        map.put("THREE", 3);
	         
	        map.put("FOUR", 4);
	        System.out.println(map);
			 
	        LinkedHashMap<String, Integer> maps = new LinkedHashMap<String, Integer>(); 
	        maps.put("ONE", 1);
	        
	        maps.put("TWO", 2);
	         
	        maps.put("THREE", 3);
	         
	        maps.put("FOUR", 4);
	        System.out.println(maps);
	        TreeMap<String, Integer> mapss = new TreeMap<String, Integer>();  
	        mapss.put("ONE", 1);
	        
	        mapss.put("TWO", 2);
	         
	        mapss.put("THREE", 3);
	         
	        mapss.put("FOUR", 4);
	      System.out.println( mapss.entrySet()); 
	        System.out.println(mapss);
	        
	        
	    }   
	}



