package TreeandMap;

import java.util.HashMap;
import java.util.Map;



public class MapExample {
	
	

	public static void main(String[] args) {
		Map<String, Integer> map=new HashMap<>();
		 map.put ("Apple",3);
		 map.put ("Banana",5);
		 map.put ("Orange",2);
		 System.out.println("Apple count:"+map.get("Apple"));
		for(Map.Entry<String, Integer>entry : map.entrySet()) {
			System.out.println(entry.getKey()+""+ entry.getValue());
			
		}
		if(map.containsKey("Banana")) {
			System.out.println("Banana exists");
		}
		map.remove("Orange");
		System.out.println("Size:"+map.size());
	}

}
