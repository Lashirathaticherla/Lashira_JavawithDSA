package searchingandsorting;

public class Bubblesort {
	static int array[]= {2,1,6,5,4};

	public static void main(String[] args) {
		int length= array.length;
		System.out.println("umsorted array");
		for(int i=0;i<length;i++) {
			System.out.println("array[i");
		}
		System.out.println("unsorted array");
		      bubblesort(array,length);
			
		// TODO Auto-generated method stub

	}

	private static void bubblesort(int[] array2, int length) {
		for(int i=0;i<length -1;i++) {
			for (int j=i+i;j<length;j++) {
				int temp;
				if(array[i]>array[j]) {
					temp=array[i];
					array[i]=array[j];
					array[j]=temp;
					
				}
				
			}
		}
		for(int i=0;i<length;i++) {
			System.out.println(array[i]);
		}
		// TODO Auto-generated method stub
		
	}

}
