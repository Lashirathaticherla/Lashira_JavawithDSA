package searchingandsorting;

public class linearsearch {
public static int linearsearch (int arr[],int n,int val)
{
	for(int i=0;i<n;i++)
	{
		if(arr[i]==val)
			return i;
	}
	return -1;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{
			int arr[]= {12,25,8,10,32};
			int x=8;
			int result=linearsearch(arr,arr.length,x);
			if(result==-1)
				System.out.print("Element is not present in array");
			else
				System.out.print("Element is present at index:"+result);
						

	}

	}
}

	